$ErrorActionPreference = "Stop"
Write-Host "NNIT Studio bootstrap" -ForegroundColor Cyan
Set-Location $PSScriptRoot
if (-not (Get-Command node -ErrorAction SilentlyContinue)) { throw "Node.js 20+ is required." }
if (-not (Test-Path .env)) { Copy-Item .env.example .env }
npm install
npm run db:init
npm run doctor
npm run dev:core
