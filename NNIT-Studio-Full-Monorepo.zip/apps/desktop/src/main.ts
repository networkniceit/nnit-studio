import {app,BrowserWindow} from 'electron';
const create=()=>{const win=new BrowserWindow({width:1500,height:950,minWidth:1000,minHeight:700,backgroundColor:'#0b0d12',webPreferences:{contextIsolation:true,sandbox:true}});win.loadURL(process.env.NNIT_STUDIO_WEB_URL||'http://localhost:5173');};
app.whenReady().then(create); app.on('window-all-closed',()=>{if(process.platform!=='darwin')app.quit();});
