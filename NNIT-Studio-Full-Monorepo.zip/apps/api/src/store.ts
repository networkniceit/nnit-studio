import { randomUUID } from 'node:crypto';
export type Project={id:string;ownerId:string;name:string;bpm:number;key?:string;sampleRate:number;bitDepth:number;tracks:any[];createdAt:string;updatedAt:string};
const now=()=>new Date().toISOString();
export const db={projects:new Map<string,Project>(), aiJobs:new Map<string,any>(), marketplace:new Map<string,any>()};
export function newProject(name:string,ownerId='demo-user'):Project { const t=now(); const p={id:randomUUID(),ownerId,name,bpm:120,sampleRate:48000,bitDepth:24,tracks:[{id:randomUUID(),name:'Vocal 1',kind:'audio',gainDb:0,pan:0,mute:false,solo:false,armed:true,effects:[],clips:[]}],createdAt:t,updatedAt:t}; db.projects.set(p.id,p); return p; }
