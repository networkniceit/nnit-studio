import Fastify from 'fastify'; import cors from '@fastify/cors'; import websocket from '@fastify/websocket'; import { projectRoutes } from './routes/projects.js'; import { aiRoutes } from './routes/ai.js'; import { businessRoutes } from './routes/business.js'; import { newProject } from './store.js';
const app=Fastify({logger:true}); await app.register(cors,{origin:true}); await app.register(websocket);
app.get('/health',async()=>({ok:true,service:'nnit-studio-api',version:'0.1.0'}));
app.get('/api/features',async()=>({recording:true,multitrack:true,midi:true,beatMaker:true,mixer:true,mastering:true,ai:true,collaboration:true,marketplace:true,nnitId:true,nnitPay:true,mobile:true,desktop:true,web:true}));
await app.register(projectRoutes); await app.register(aiRoutes); await app.register(businessRoutes);
app.get('/ws/projects/:id',{websocket:true},(socket,req:any)=>{socket.send(JSON.stringify({type:'connected',projectId:req.params.id}));socket.on('message',data=>socket.send(JSON.stringify({type:'ack',received:data.toString()})));});
newProject('NNIT Studio Demo');
const port=Number(process.env.PORT||4000); await app.listen({port,host:'0.0.0.0'});
