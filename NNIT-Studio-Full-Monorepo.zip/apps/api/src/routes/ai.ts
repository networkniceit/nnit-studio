import { FastifyInstance } from 'fastify'; import { randomUUID } from 'node:crypto'; import { db } from '../store.js';
const allowed=new Set(['stem-separation','denoise','vocal-isolation','bpm-detection','key-detection','mix-assist','master-assist','transcription','harmony']);
export async function aiRoutes(app:FastifyInstance){
 app.get('/api/ai/capabilities',async()=>({items:[...allowed]}));
 app.post('/api/ai/jobs',async(req:any,reply)=>{const type=String(req.body?.type||''); if(!allowed.has(type)) return reply.code(400).send({error:'Unsupported AI job'}); const job={id:randomUUID(),type,status:'queued',progress:0,input:req.body?.input||{},createdAt:new Date().toISOString()}; db.aiJobs.set(job.id,job); setTimeout(()=>{const j=db.aiJobs.get(job.id); if(j){j.status='done';j.progress=100;j.result={integrationReady:true,message:'Connect production AI/DSP worker to execute this job.'};}},50); reply.code(202); return job;});
 app.get('/api/ai/jobs/:id',async(req:any,reply)=>db.aiJobs.get(req.params.id)||reply.code(404).send({error:'Job not found'}));
}
