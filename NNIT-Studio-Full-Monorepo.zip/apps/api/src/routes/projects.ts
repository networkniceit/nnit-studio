import { FastifyInstance } from 'fastify'; import { db,newProject } from '../store.js';
export async function projectRoutes(app:FastifyInstance){
 app.get('/api/projects',async()=>({items:[...db.projects.values()]}));
 app.post('/api/projects',async(req:any,reply)=>{const name=String(req.body?.name||'Untitled Project').slice(0,120); reply.code(201); return newProject(name);});
 app.get('/api/projects/:id',async(req:any,reply)=>{const p=db.projects.get(req.params.id); if(!p) return reply.code(404).send({error:'Project not found'}); return p;});
 app.patch('/api/projects/:id',async(req:any,reply)=>{const p=db.projects.get(req.params.id); if(!p) return reply.code(404).send({error:'Project not found'}); Object.assign(p,req.body||{}, {id:p.id,updatedAt:new Date().toISOString()}); return p;});
 app.delete('/api/projects/:id',async(req:any,reply)=>{db.projects.delete(req.params.id); return reply.code(204).send();});
}
