import { FastifyInstance } from 'fastify'; import { randomUUID } from 'node:crypto'; import { db } from '../store.js'; import { NNITPayService } from '../services/integrations.js';
export async function businessRoutes(app:FastifyInstance){ const pay=new NNITPayService();
 app.get('/api/plans',async()=>({items:[{id:'free',monthly:0},{id:'creator',monthly:14.99},{id:'pro',monthly:29.99},{id:'enterprise',monthly:null}]}));
 app.post('/api/billing/checkout',async(req:any)=>pay.checkout(String(req.body?.plan||'creator'),String(req.body?.currency||'EUR')));
 app.get('/api/marketplace',async()=>({items:[...db.marketplace.values()]}));
 app.post('/api/marketplace',async(req:any,reply)=>{const item={id:randomUUID(),title:req.body?.title||'Untitled',type:req.body?.type||'sound-pack',priceMinor:Number(req.body?.priceMinor||0),currency:req.body?.currency||'EUR',status:'draft'};db.marketplace.set(item.id,item);reply.code(201);return item;});
}
